random seed 20261005
gds read $env(JOINT_GDS)
load pixel_integrated
select top cell
flatten -nolabels pixel_flat
load pixel_flat
select top cell
box values 150.000um 144.840um 150.560um 145.400um
label {clk} center metal3
port make
box values 150.000um 97.800um 150.560um 98.360um
label {duty[0]} center metal3
port make
box values 150.000um 100.040um 150.560um 100.600um
label {duty[1]} center metal3
port make
box values 150.000um 98.920um 150.560um 99.480um
label {duty[2]} center metal3
port make
box values 150.000um 112.360um 150.560um 112.920um
label {duty[3]} center metal3
port make
box values 150.000um 103.400um 150.560um 103.960um
label {duty[4]} center metal3
port make
box values 150.000um 116.840um 150.560um 117.400um
label {duty[5]} center metal3
port make
box values 150.000um 130.280um 150.560um 130.840um
label {duty[6]} center metal3
port make
box values 150.000um 135.880um 150.560um 136.440um
label {duty[7]} center metal3
port make
box values 150.000um 126.920um 150.560um 127.480um
label {duty[8]} center metal3
port make
box values 150.000um 117.960um 150.560um 118.520um
label {enable} center metal3
port make
box values 150.000um 138.120um 150.560um 138.680um
label {rst} center metal3
port make
box values 25.000um 107.220um 28.000um 107.820um
label {bias} center metal3
port make
box values 25.000um 109.220um 28.000um 109.820um
label {gate} center metal3
port make
box values 25.000um 113.220um 28.000um 113.820um
label {pwm_b} center metal3
port make
box values 25.000um 115.220um 28.000um 115.820um
label {led_k} center metal3
port make
box values 139.650um 116.500um 140.350um 117.520um
label {VDD} center metal4
port make
box values 134.650um 104.500um 135.350um 105.520um
label {VSS} center metal5
port make
box values 125.000um 111.240um 126.000um 111.800um
label {pwm_monitor} center metal3
port make
box values 161.470um 109.830um 161.490um 109.850um
label {DRIVER_I} center metal1
port make
box values 159.230um 108.710um 159.250um 108.730um
label {DRIVER_Z} center metal1
port make
box values 119.980um 111.510um 120.000um 111.530um
label {ANALOG_PWM} center metal3
port make
drc style drc(full)
drc check
drc catchup
puts "FLAT_DRC_COUNT [drc list count total]"
save pixel_flat
extract style ngspice()
extract do capacitance
extract do coupling
extresist threshold 0
extresist minres 0
extresist mindelay 0
extract do resistance
extract all
ext2spice lvs
ext2spice cthresh 0
ext2spice rthresh 0
ext2spice extresist on
ext2spice -o pixel_flat_rc.spice
quit -noprompt
